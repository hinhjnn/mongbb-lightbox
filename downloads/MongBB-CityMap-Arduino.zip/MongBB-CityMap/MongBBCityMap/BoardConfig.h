#pragma once
// REFERENCE wiring only: ESP32-WROOM-32, 64x64 HUB75E 1/32 scan.
// Confirm the panel driver IC, IN header and power supply before wiring/uploading.
// A matching scan count alone does not identify the driver IC.
#ifndef MONG_PANEL_ENABLED
#define MONG_PANEL_ENABLED 1
#endif
#define MONG_BRIGHTNESS_CAP 32 // 32/255 duty setting, NOT a current or power guarantee.
#if MONG_PANEL_ENABLED
#include <ESP32-HUB75-MatrixPanel-I2S-DMA.h>
static const HUB75_I2S_CFG::i2s_pins PANEL_PINS = {
  25,26,27, 14,32,33, // R1 G1 B1 R2 G2 B2
  23,19,18,17,16,    // A B C D E (E is required for 64x64 / 1:32)
  4,21,22           // LAT OE CLK
};
// Adjustable assumption: standard shift-register driver. FM6126A etc need matching setting.
static const auto PANEL_DRIVER = HUB75_I2S_CFG::SHIFTREG;
#endif
