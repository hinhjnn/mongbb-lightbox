/* MongBB City Map — ESP32-WROOM-32 + 64x64 HUB75E / 1:32.
 * Arduino IDE: install ESP32 by Espressif, ArduinoJson 7.4.3,
 * ESP32 HUB75 LED MATRIX PANEL DMA Display 3.0.14, Adafruit GFX Library.
 * Select ESP32 Dev Module. Read BoardConfig.h and README before wiring.
 * Serial Monitor: 115200 baud, Newline. Close it before browser USB connection.
 */
#include <Arduino.h>
#include <LittleFS.h>
#include "Controller.h"
#include "BoardConfig.h"
#include "WorldMap.h"
#include "Cities.h"
using namespace mongbb;
Controller controller;
LineReceiver receiver;
#if MONG_PANEL_ENABLED
MatrixPanel_I2S_DMA* panel=nullptr;
#endif
struct CityState { uint8_t on[CITY_COUNT],level[CITY_COUNT],base; } cityState;
struct SaveHeader {uint32_t magic,version,sceneSize,sceneCrc,citySize,cityCrc,layout;};
bool storageReady=false;
uint32_t layoutHash(){
 uint32_t h=crc32(WORLD_MAP,sizeof(WORLD_MAP));
 for(const auto& c:CITIES){h=h*16777619u^crc32(c.id,strlen(c.id));h=h*16777619u^crc32(c.pixels,c.count*sizeof(uint16_t));}return h;
}
bool saveCurrent(const Scene& scene){
 if(!storageReady)return false;
 SaveHeader h={0x4d424243,1,sizeof(Scene),crc32(&scene,sizeof scene),sizeof(cityState),crc32(&cityState,sizeof cityState),layoutHash()};
 File f=LittleFS.open("/citymap.tmp","w");if(!f)return false;
 bool ok=f.write(reinterpret_cast<uint8_t*>(&h),sizeof h)==sizeof h&&
  f.write(reinterpret_cast<const uint8_t*>(&scene),sizeof scene)==sizeof scene&&
  f.write(reinterpret_cast<uint8_t*>(&cityState),sizeof cityState)==sizeof cityState;
 f.flush();f.close();
 if(!ok){LittleFS.remove("/citymap.tmp");return false;}
 // LittleFS rename replaces the previous file atomically; incomplete .tmp is never loaded.
 return LittleFS.rename("/citymap.tmp","/citymap.bin");
}
bool loadSaved(){
 if(!storageReady)return false;
 File f=LittleFS.open("/citymap.bin","r");if(!f)return false;SaveHeader h{};
 if(f.read(reinterpret_cast<uint8_t*>(&h),sizeof h)!=sizeof h||h.magic!=0x4d424243||h.version!=1||
 h.sceneSize!=sizeof(Scene)||h.citySize!=sizeof cityState||h.layout!=layoutHash()||
 f.size()!=sizeof h+sizeof(Scene)+sizeof cityState){f.close();return false;}
 bool ok=f.read(reinterpret_cast<uint8_t*>(&controller.active),sizeof(Scene))==sizeof(Scene)&&
 f.read(reinterpret_cast<uint8_t*>(&cityState),sizeof cityState)==sizeof cityState;
 f.close();
 ok=ok&&crc32(&controller.active,sizeof(Scene))==h.sceneCrc&&crc32(&cityState,sizeof cityState)==h.cityCrc&&validScene(controller.active);
 for(unsigned i=0;i<CITY_COUNT;i++)ok=ok&&cityState.on[i]<=1;
 if(ok)controller.restore(controller.active,millis());return ok;
}
void basePoint(unsigned p){
 bool on=cityState.base>0&&WORLD_MAP[p/64][p%64]=='1';
 pixel(controller.active,p,on,scaledColor(0x62bde8,cityState.base));
}
void applyCity(unsigned index){
 const auto& city=CITIES[index];
 for(unsigned k=0;k<city.count;k++){
  if(cityState.on[index]&&cityState.level[index]>0)pixel(controller.active,city.pixels[k],true,scaledColor(city.color,cityState.level[index]));
  else basePoint(city.pixels[k]);
 }
}
// Call from setup() or your own program. All pixels in a city region change together.
bool setCity(const char* id,bool on,uint8_t brightness){
 for(unsigned i=0;i<CITY_COUNT;i++)if(!strcmp(id,CITIES[i].id)){
  controller.freezeAt(millis());controller.active.config.on=1;cityState.on[i]=on;cityState.level[i]=brightness;applyCity(i);return true;
 }return false;
}
void setPoint(uint8_t x,uint8_t y,bool on,uint8_t brightness){
 if(x>=64||y>=64)return;controller.freezeAt(millis());controller.active.config.on=1;
 pixel(controller.active,y*64+x,on&&brightness>0,scaledColor(0xffd080,brightness));
}
void makeDefault(){
 memset(&controller.active,0,sizeof(Scene));
 controller.active.config={1,0,0,0,1,0,0,4,.05,{0x62bde8,0x62bde8,0x62bde8}};
 cityState.base=CITY_BASE_BRIGHTNESS;
 for(unsigned p=0;p<4096;p++)basePoint(p);
 for(unsigned i=0;i<CITY_COUNT;i++){
  cityState.on[i]=CITIES[i].defaultOn;
  cityState.level[i]=CITIES[i].defaultBrightness;applyCity(i);
 }
 controller.restore(controller.active,millis());
}
void help(){
 Serial.println("MongBB City Map | 64x64 | origin top-left | x right, y down");
 Serial.println("city HongKong on 160 | city Tokyo off | point 50 35 on 180");
 Serial.println("map 32 | map 0 | breathe 4 | steady | pause | play | off | save | defaults | list");
 Serial.println("City off returns to the dim map; map 0 makes unlit city pixels completely dark.");
 Serial.println("Reference wiring/driver, uncalibrated brightness. Close Serial Monitor to use browser USB.");
 Serial.println("First-time storage only: format-storage ERASE (erases this firmware's LittleFS partition).");
}
bool integer(const char* token,int lo,int hi,int& value){if(!token||!*token)return false;char* end=nullptr;long n=strtol(token,&end,10);if(*end||n<lo||n>hi)return false;value=int(n);return true;}
void textCommand(const char* line){
 char copy[256];if(strlen(line)>=sizeof(copy)){Serial.println("ERR command too long");return;}strcpy(copy,line);
 char* saveptr=nullptr;char* op=strtok_r(copy," ",&saveptr);if(!op)return;
 auto next=[&](){return strtok_r(nullptr," ",&saveptr);};
 if(!strcmp(op,"help")){help();return;}
 if(!strcmp(op,"list")){for(unsigned i=0;i<CITY_COUNT;i++){Serial.printf("%s %s:",CITIES[i].id,CITIES[i].name);for(unsigned k=0;k<CITIES[i].count;k++){auto p=CITIES[i].pixels[k];Serial.printf(" (%u,%u)",p%64,p/64);}Serial.println();}return;}
 if(!strcmp(op,"city")){
  char* id=next();char* state=next();char* level=next();int brightness=160;
  if(!id||!state||(strcmp(state,"on")&&strcmp(state,"off"))||(level&&!integer(level,0,255,brightness))||next()||!setCity(id,!strcmp(state,"on"),brightness)){Serial.println("ERR city <id> on|off [0..255]; use list");return;}
 }else if(!strcmp(op,"point")){
  int x,y,brightness=160;char* a=next();char* b=next();char* state=next();char* level=next();
  if(!integer(a,0,63,x)||!integer(b,0,63,y)||!state||(strcmp(state,"on")&&strcmp(state,"off"))||(level&&!integer(level,0,255,brightness))||next()){Serial.println("ERR point <x 0..63> <y 0..63> on|off [0..255]");return;}
  setPoint(x,y,!strcmp(state,"on"),brightness);
 }else if(!strcmp(op,"map")){
  int level;if(!integer(next(),0,255,level)||next()){Serial.println("ERR map <0..255>");return;}
  controller.freezeAt(millis());cityState.base=level;for(unsigned p=0;p<4096;p++)basePoint(p);for(unsigned i=0;i<CITY_COUNT;i++)applyCity(i);controller.active.config.on=1;
 }else if(!strcmp(op,"breathe")){
  char* period=next();char* end=nullptr;float seconds=period?strtof(period,&end):4;
  if((period&&(*end||!finiteRange(seconds,2,30)))||next()){Serial.println("ERR breathe <2..30 seconds>");return;}
  controller.freezeAt(millis());controller.active.config.breathe=1;controller.active.config.running=1;controller.active.config.period=seconds;
 }else if(!strcmp(op,"steady")){controller.freezeAt(millis());controller.active.config.breathe=0;
 }else if(!strcmp(op,"pause")){controller.freezeAt(millis());controller.active.config.running=0;
 }else if(!strcmp(op,"play")){controller.freezeAt(millis());controller.active.config.running=1;
 }else if(!strcmp(op,"off")){controller.freezeAt(millis());controller.active.config.on=0;
 }else if(!strcmp(op,"save")){controller.freezeAt(millis());Serial.println(saveCurrent(controller.active)?"OK saved":"ERR storage unavailable or write failed");return;
 }else if(!strcmp(op,"defaults")){makeDefault();
 }else if(!strcmp(op,"format-storage")){
  char* confirmation=next();if(!confirmation||strcmp(confirmation,"ERASE")||next()){Serial.println("ERR use format-storage ERASE to erase the LittleFS partition");return;}
  LittleFS.end();storageReady=LittleFS.format()&&LittleFS.begin(false);Serial.println(storageReady?"OK empty storage ready; use save":"ERR storage format failed");return;
 }else{Serial.println("ERR unknown command; use help");return;}
 Serial.println("OK received (physical LED output not measured)");
}
void setup(){
 Serial.setRxBufferSize(4096);Serial.begin(115200);
 Serial.println("{\"event\":\"boot\",\"protocol\":\"mongbb-usb/1\"}");
 // Never silently format an existing filesystem. A fresh board can run without storage.
 storageReady=LittleFS.begin(false);if(!loadSaved())makeDefault();
 controller.saveScene=saveCurrent;controller.brightnessCap=MONG_BRIGHTNESS_CAP;
#if MONG_PANEL_ENABLED
 HUB75_I2S_CFG config(64,64,1);config.gpio=PANEL_PINS;config.driver=PANEL_DRIVER;
 // Match the stock library's 8-bit CIE LUT in both Arduino IDE and PlatformIO.
 config.double_buff=true;config.setPixelColorDepthBits(8);config.i2sspeed=HUB75_I2S_CFG::HZ_10M;
 panel=new MatrixPanel_I2S_DMA(config);controller.outputEnabled=panel->begin();
 if(controller.outputEnabled){panel->setBrightness8(MONG_BRIGHTNESS_CAP);panel->clearScreen();}
 else Serial.println("Panel DMA allocation failed; USB still available, output disabled.");
#else
 Serial.println("USB-only validation firmware: HUB75 pins disabled.");
#endif
 help();
}
void loop(){
 controller.phaseAt(millis()); // advance even in USB-only mode; survives millis() rollover
 unsigned count=0;while(Serial.available()&&count++<1024){
  const char* line=receiver.feed(char(Serial.read()));if(!line||!*line)continue;
  if(line[0]=='{'){JsonDocument d;auto error=deserializeJson(d,line);
   if(error){Serial.println("ERR invalid JSON");continue;}
   auto reply=controller.handle(d.as<JsonVariantConst>(),millis());serializeJson(reply,Serial);Serial.println();
  }else textCommand(line);
 }
#if MONG_PANEL_ENABLED
 static uint32_t last=0;uint32_t now=millis();
 if(controller.outputEnabled&&uint32_t(now-last)>=66){last=now;double phase=controller.phaseAt(now);
  for(unsigned p=0;p<4096;p++){float c[3];controller.sample(p,phase,c);panel->drawPixelRGB888(p%64,p/64,srgb(c[0]),srgb(c[1]),srgb(c[2]));}
  panel->flipDMABuffer();
 }
#endif
 delay(1);
}
