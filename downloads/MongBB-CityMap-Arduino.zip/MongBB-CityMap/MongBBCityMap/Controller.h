#pragma once
#include <ArduinoJson.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <functional>

namespace mongbb {
constexpr uint32_t INHERIT = 0x01000000;
struct Config {
  uint8_t on, gradient, breathe, running;
  float brightness, direction, speed, period, minimum;
  uint32_t palette[3];
};
struct Scene { Config config; double phase; uint8_t mask[512]; uint32_t colors[4096]; };
inline bool finiteRange(float n,float lo,float hi) { return isfinite(n)&&n>=lo&&n<=hi; }
inline bool validConfig(const Config& c) {
  return c.on<=1&&c.gradient<=1&&c.breathe<=1&&c.running<=1&&
    finiteRange(c.brightness,0,1)&&finiteRange(c.direction,0,360)&&finiteRange(c.speed,0,.080001f)&&
    finiteRange(c.period,2,30)&&finiteRange(c.minimum,0,1)&&
    c.palette[0]<=0xffffff&&c.palette[1]<=0xffffff&&c.palette[2]<=0xffffff;
}
inline bool validScene(const Scene& s) {
  if(!validConfig(s.config)||!isfinite(s.phase)||s.phase<0||s.phase>1e9)return false;
  for(auto color:s.colors)if(color>INHERIT)return false;
  return true;
}
inline uint32_t crc32(const void* data,size_t size) {
  uint32_t crc=~0u;const auto* p=static_cast<const uint8_t*>(data);
  while(size--){crc^=*p++;for(int i=0;i<8;i++)crc=(crc>>1)^(0xedb88320u&-(crc&1));}return ~crc;
}
inline bool hex6(const char* p,uint32_t& out) {
  out=0;for(int i=0;i<6;i++){const char c=p[i];int n=c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:c>='A'&&c<='F'?c-'A'+10:-1;if(n<0)return false;out=(out<<4)|n;}return true;
}
inline float linear(uint8_t c){float v=c/255.f;return v<=.04045f?v/12.92f:powf((v+.055f)/1.055f,2.4f);}
inline uint8_t srgb(float v){v=fmaxf(0,fminf(1,v));return uint8_t(lroundf(255*(v<=.0031308f?v*12.92f:1.055f*powf(v,1.f/2.4f)-.055f)));}
inline uint32_t scaledColor(uint32_t color,uint8_t brightness) {
  uint32_t result=0;for(int shift=16;shift>=0;shift-=8)result|=uint32_t(srgb(linear((color>>shift)&255)*brightness/255.f))<<shift;return result;
}
inline void pixel(Scene& s,unsigned i,bool on,uint32_t color=INHERIT){if(i>=4096)return;uint8_t bit=1u<<(i%8);if(on)s.mask[i/8]|=bit;else s.mask[i/8]&=~bit;s.colors[i]=color;}
inline bool isOn(const Scene& s,unsigned i){return i<4096&&(s.mask[i/8]&(1u<<(i%8)));}

class Controller {
  Scene staging{};bool transaction=false,full=false;uint64_t received=0;uint32_t touched=0,epoch=0;
  float lut[256]{};
  bool number(JsonVariantConst v,float lo,float hi){return v.is<float>()&&finiteRange(v.as<float>(),lo,hi);}
  bool parseConfig(JsonVariantConst v,Config& c){
    if(!v.is<JsonObjectConst>()||!v["on"].is<bool>()||!v["running"].is<bool>()||
      !number(v["brightness"],0,1)||!number(v["direction"],0,360)||!number(v["speed"],0,.080001f)||
      !number(v["period"],2,30)||!number(v["minimum"],0,1)||
      !(v["mode"]=="solid"||v["mode"]=="gradient")||!(v["effect"]=="steady"||v["effect"]=="breathe")||
      !v["colors"].is<JsonArrayConst>()||v["colors"].size()!=3)return false;
    for(int i=0;i<3;i++){const char* s=v["colors"][i].as<const char*>();if(!s||strlen(s)!=7||s[0]!='#'||!hex6(s+1,c.palette[i]))return false;}
    c.on=v["on"];c.running=v["running"];c.gradient=v["mode"]=="gradient";c.breathe=v["effect"]=="breathe";
    c.brightness=v["brightness"];c.direction=v["direction"];c.speed=v["speed"];c.period=v["period"];c.minimum=v["minimum"];
    return true;
  }
public:
  Scene active{};bool ready=false,outputEnabled=false;uint8_t brightnessCap=32;
  std::function<bool(const Scene&)> saveScene;
  Controller(){
    active.config={0,0,0,0,1,0,0,4,.05,{0x62bde8,0x62bde8,0x62bde8}};
    for(auto& color:active.colors)color=INHERIT;
    for(int i=0;i<256;i++)lut[i]=linear(i);
  }
  void restore(const Scene& s,uint32_t now){if(validScene(s)){active=s;epoch=now;ready=true;transaction=false;}}
  double phaseAt(uint32_t now){
    if(active.config.running)active.phase+=uint32_t(now-epoch)/1000.0;
    epoch=now;return active.phase;
  }
  void freezeAt(uint32_t now){active.phase=phaseAt(now);epoch=now;transaction=false;}
  void sample(unsigned i,double phase,float out[3])const {
    out[0]=out[1]=out[2]=0;if(!ready||!active.config.on||!isOn(active,i))return;
    const auto& c=active.config;const float angle=c.direction*float(M_PI)/180;
    float p=float(fmod(((i%64)/63.f*cosf(angle)+(i/64)/63.f*sinf(angle))*.65f+phase*c.speed,1.0));
    float t=(1-cosf(p*2*float(M_PI)))/2,f=t<.5f?t*2:(t-.5f)*2;
    uint32_t a=c.palette[t<.5f?0:1],b=c.palette[t<.5f?1:2],override=active.colors[i];
    float envelope=c.breathe?c.minimum+(1-c.minimum)*(1+cos(float(fmod(phase,c.period)*2*M_PI/c.period)))/2:1;
    for(int ch=0;ch<3;ch++){int shift=16-8*ch;float value;
      if(override!=INHERIT)value=lut[(override>>shift)&255];
      else if(!c.gradient)value=lut[(c.palette[0]>>shift)&255];
      else value=lut[(a>>shift)&255]*(1-f)+lut[(b>>shift)&255]*f;
      out[ch]=value*c.brightness*envelope;
    }
  }
  JsonDocument handle(JsonVariantConst d,uint32_t now){
    JsonDocument r;r["v"]=1;r["device"]="MongBB";r["id"]=d["id"]|0;r["ok"]=false;
    auto fail=[&](const char* reason){r["error"]=reason;return r;};
    if(transaction&&uint32_t(now-touched)>8000)transaction=false;
    if(d["v"]!=1||!d["id"].is<uint32_t>()||!d["op"].is<const char*>())return fail("invalid envelope");
    const char* op=d["op"];
    if(!strcmp(op,"hello")){
      r["protocol"]="mongbb-usb/1";r["firmware"]="1.1.0";r["width"]=64;r["height"]=64;
      r["outputEnabled"]=outputEnabled;r["brightnessCap"]=brightnessCap;r["hasScene"]=ready;
    }else if(!strcmp(op,"begin")){
      transaction=false;Config c{};
      if(!d["full"].is<bool>()||!parseConfig(d["config"],c))return fail("invalid source config");
      if(!ready&&!d["full"].as<bool>())return fail("first scene requires all rows");
      staging=active;staging.config=c;full=d["full"];received=0;transaction=true;touched=now;
    }else if(!strcmp(op,"row")){
      if(!transaction)return fail("no transaction");
      const char* mask=d["mask"].as<const char*>();const char* colors=d["colors"].as<const char*>();
      if(!d["y"].is<unsigned>()||d["y"].as<unsigned>()>=64||!mask||strlen(mask)!=64||!colors||strlen(colors)!=384){transaction=false;return fail("invalid row size");}
      uint32_t parsed[64];
      for(unsigned x=0;x<64;x++){
        if(mask[x]!='0'&&mask[x]!='1'){transaction=false;return fail("invalid mask");}
        if(!strncmp(colors+x*6,"------",6))parsed[x]=INHERIT;
        else if(!hex6(colors+x*6,parsed[x])){transaction=false;return fail("invalid colour");}
      }
      unsigned y=d["y"];for(unsigned x=0;x<64;x++)pixel(staging,y*64+x,mask[x]=='1',parsed[x]);
      received|=uint64_t(1)<<y;touched=now;
    }else if(!strcmp(op,"commit")){
      if(!transaction)return fail("no transaction");
      transaction=false;
      if((full&&received!=UINT64_MAX)||!d["phase"].is<double>()||!isfinite(d["phase"].as<double>())||d["phase"].as<double>()<0||d["phase"].as<double>()>1e9)return fail("incomplete scene or invalid phase");
      staging.phase=d["phase"];active=staging;epoch=now;ready=true;r["phase"]=active.phase;
    }else if(!strcmp(op,"off")){
      freezeAt(now);active.config.on=0;
    }else if(!strcmp(op,"save")){
      if(transaction||!ready||!saveScene)return fail("no complete scene or storage unavailable");
      // Save the current phase without copying the 17KB scene onto the task stack.
      active.phase=phaseAt(now);epoch=now;
      if(!saveScene(active))return fail("storage write failed");
    }else return fail("unknown command");
    r["ok"]=true;return r;
  }
};
// Shared bounded newline parser. Oversized input is discarded until the next newline.
class LineReceiver {
  char buffer[1024]{};size_t length=0;bool dropping=false;
public:
  const char* feed(char c){
    if(c=='\r')return nullptr;
    if(c=='\n'){if(dropping){dropping=false;length=0;return nullptr;}buffer[length]=0;length=0;return buffer;}
    if(!dropping){if(length<sizeof(buffer)-1)buffer[length++]=c;else{dropping=true;length=0;}}
    return nullptr;
  }
};
}
