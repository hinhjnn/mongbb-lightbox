# MongBB City Map · Arduino IDE / USB

完整圖文說明與 156 城市名錄：解壓後開啟 `guide/arduino-guide.html`，或線上 https://hinhjnn.github.io/mongbb-lightbox/downloads/arduino-guide.html 。

1. Arduino IDE 開啟 `MongBBCityMap/MongBBCityMap.ino`，同資料夾 4 個 `.h` 必須保留。
2. Boards Manager：**esp32 by Espressif Systems 2.0.17**；板型 **ESP32 Dev Module**，PSRAM Disabled。
3. Library Manager：**ArduinoJson 7.4.3**、**ESP32 HUB75 LED MATRIX PANEL DMA Display 3.0.14**、**Adafruit GFX Library 1.12.1** 及其 BusIO 依賴。
4. `BoardConfig.h` 為 WROOM-32 + 64×64 1/32 HUB75E 的可調參考接線；SHIFTREG 驅動 IC 尚未確認。只試 USB，把 `MONG_PANEL_ENABLED` 改為 0。對照實物確認才接燈板版本。
5. Verify，再選正確 Port / Upload。Serial Monitor：115200 baud，Newline。

```text
map 0
city HongKong on 160
city Tokyo on 100
city London on 200
breathe 4
steady
list
save
```

城市關閉會回到底圖；map 0 才完全黑色。預設 HK (50,35)、Tokyo (53,32)、London (30,29) 亮燈。

修改城市：網站下載 `Cities.h`，覆蓋後重新編譯／上傳。板內已有保存圖案時，輸入 `defaults` 讀取新預設，再 `save`。網站命名資料用「城市設定 JSON」另外保存。USB 傳像素與效果，不會重寫已編譯的城市名錄。

上電可還原 LittleFS 保存圖案；不會自動格式化。全新專用板若保存失敗，確認分區沒有需保留資料後才手動輸入 `format-storage ERASE`，再 `save`。

燈板須用符合標示的獨立電源，與 ESP32 共地；USB 只供開發板。不可經 ESP32 的 3.3V 或 USB 供應整板。ESP32 為 3.3V 邏輯，必要時用合適 5V 邏輯緩衝器。32/255 輸出上限不是限流或安全保證。接線時先關電。詳見 guide。

網站 USB：電腦 Chrome → 關閉 Serial Monitor → 連接 ESP32 → 傳送目前圖案／即時同步。接收有 ACK；斷線有供電時繼續播放，熄燈需先按「實物全關」。CCT／材料／曝光／Bloom 只屬模擬。

## 程式檔案
- `MongBBCityMap.ino`：Arduino setup/loop、Serial Monitor 城市指令、LittleFS、HUB75 adapter。
- `Controller.h`：可獨立執行測試的 USB 交易、線性 RGB 與呼吸核心。
- `Cities.h`：156 城市／164 獨立控制點，名稱、ID、預設顏色及亮度。
- `WorldMap.h`：64 行 ×64 的底圖。
- `BoardConfig.h`：可調 GPIO、驅動種類、亮度上限。

座標原點左上，index=y*64+x，x/y=0..63；參考藝術圖等比例置中 y=16..47。位置經美術移位，區域不是行政面積。每城市 1–8 點，不重疊。

## 可重跑的編譯（完整原始碼包）

```sh
python3 -m venv .venv
.venv/bin/pip install platformio==6.1.18
.venv/bin/pio run -d firmware -e usb-check -e hub75-reference
```

兩個設定使用相同 `.ino`、固定 Arduino-ESP32 2.0.17。預設 `pio run -d firmware` 只編 USB 檢查版，不上傳。HUB75 版測到的是編譯，尚未實物測試。PWM 使用 8-bit 色深，螢幕與實物未校準，亮度控制不是 lux 或耗電數值。

測試（完整 source 包，先裝 PlatformIO 依賴及 npm 依賴）：

```sh
npm run test:firmware
python3 scripts/check-hub75-depth.py
npm run build
```

若使用自訂 library cache，分別設定 `MONG_ARDUINOJSON_DIR`（ArduinoJson/src）及 `MONG_HUB75_DIR`（HUB75 library 根目錄）。第一個指令會編譯真正 C++ 核心並與網站輸出比對，只有此路徑會執行 native integration case。macOS/Linux 需 C++17 compiler；測試不會燒錄硬件。
